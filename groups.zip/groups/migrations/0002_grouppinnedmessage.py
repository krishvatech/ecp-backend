from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ("groups", "0001_initial"),
        ("messaging", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="GroupPinnedMessage",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("pinned_at", models.DateTimeField(auto_now_add=True)),
                ("is_global", models.BooleanField(default=False, db_index=True)),
                (
                    "group",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="pinned_messages",
                        to="groups.group",
                    ),
                ),
                (
                    "message",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="group_pins",
                        to="messaging.message",
                    ),
                ),
                (
                    "pinned_by",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="pinned_group_messages",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
                (
                    "user",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="personal_group_pins",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
        ),
        migrations.AddConstraint(
            model_name="grouppinnedmessage",
            constraint=models.UniqueConstraint(
                fields=["group", "message"],
                condition=models.Q(is_global=True),
                name="uniq_global_pin_per_group_message",
            ),
        ),
        migrations.AddConstraint(
            model_name="grouppinnedmessage",
            constraint=models.UniqueConstraint(
                fields=["group", "message", "user"],
                condition=models.Q(is_global=False),
                name="uniq_personal_pin_per_user",
            ),
        ),
        migrations.AddIndex(
            model_name="grouppinnedmessage",
            index=models.Index(
                fields=["group", "pinned_at"],
                name="groups_grou_group_i_842697_idx",
            ),
        ),
    ]
