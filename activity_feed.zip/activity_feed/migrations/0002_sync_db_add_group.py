from django.db import migrations

class Migration(migrations.Migration):
    dependencies = [
        ("activity_feed", "0001_initial"),
    ]

    operations = [
        migrations.SeparateDatabaseAndState(
            database_operations=[
                migrations.RunSQL(
                    """
DO $$
BEGIN
  -- add column if missing
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public'
      AND table_name='activity_feed_feeditem'
      AND column_name='group_id'
  ) THEN
    ALTER TABLE public.activity_feed_feeditem
      ADD COLUMN group_id bigint NULL;
  END IF;

  -- FK if missing
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'activity_feed_feeditem_group_id_fk'
  ) THEN
    ALTER TABLE public.activity_feed_feeditem
      ADD CONSTRAINT activity_feed_feeditem_group_id_fk
      FOREIGN KEY (group_id) REFERENCES public.groups_group (id)
      DEFERRABLE INITIALLY DEFERRED;
  END IF;

  -- index on group_id
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
    WHERE c.relname='activity_feed_feeditem_group_id_idx' AND n.nspname='public'
  ) THEN
    CREATE INDEX activity_feed_feeditem_group_id_idx
      ON public.activity_feed_feeditem (group_id);
  END IF;

  -- (group_id, created_at)
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
    WHERE c.relname='activity_fe_group_i_428b15_idx' AND n.nspname='public'
  ) THEN
    CREATE INDEX activity_fe_group_i_428b15_idx
      ON public.activity_feed_feeditem (group_id, created_at);
  END IF;

  -- (community_id, group_id, created_at)
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
    WHERE c.relname='activity_fe_communi_8457f5_idx' AND n.nspname='public'
  ) THEN
    CREATE INDEX activity_fe_communi_8457f5_idx
      ON public.activity_feed_feeditem (community_id, group_id, created_at);
  END IF;
END$$;
""",
                    reverse_sql="""
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'activity_feed_feeditem_group_id_fk') THEN
    ALTER TABLE public.activity_feed_feeditem DROP CONSTRAINT activity_feed_feeditem_group_id_fk;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
             WHERE c.relname='activity_fe_communi_8457f5_idx' AND n.nspname='public') THEN
    DROP INDEX public.activity_fe_communi_8457f5_idx;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
             WHERE c.relname='activity_fe_group_i_428b15_idx' AND n.nspname='public') THEN
    DROP INDEX public.activity_fe_group_i_428b15_idx;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
             WHERE c.relname='activity_feed_feeditem_group_id_idx' AND n.nspname='public') THEN
    DROP INDEX public.activity_feed_feeditem_group_id_idx;
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public'
      AND table_name='activity_feed_feeditem'
      AND column_name='group_id'
  ) THEN
    ALTER TABLE public.activity_feed_feeditem DROP COLUMN group_id;
  END IF;
END$$;
""",
                ),
            ],
            state_operations=[],  # state already includes the field via 0001
        ),
    ]
