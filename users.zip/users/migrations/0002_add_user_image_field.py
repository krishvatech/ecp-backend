from django.db import migrations, models
import users.models  # for user_profile_image if referenced

class Migration(migrations.Migration):
    dependencies = [
        ("users", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="userprofile",
            name="user_image",
            field=models.ImageField(upload_to=users.models.user_profile_image, null=True, blank=True),
        ),
    ]
