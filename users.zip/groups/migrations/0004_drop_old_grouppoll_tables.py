from django.db import migrations

SQL = """
-- Safe in Postgres & SQLite
DROP TABLE IF EXISTS groups_grouppollvote;
DROP TABLE IF EXISTS groups_grouppolloption;
DROP TABLE IF EXISTS groups_grouppoll;
"""

class Migration(migrations.Migration):
    dependencies = [
        ("groups", "0003_remove_grouppolloption_poll_and_more"),
    ]
    operations = [
        migrations.RunSQL(SQL, reverse_sql=migrations.RunSQL.noop),
    ]
