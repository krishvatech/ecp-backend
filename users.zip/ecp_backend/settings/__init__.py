# This file exists so that Python treats the settings package as a module.
# Settings are split into base, dev, and prod configurations.  The
# environment variable DJANGO_SETTINGS_MODULE points to which module is
# in use.  The default is dev (see manage.py and asgi.py).