from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("events", "0001_initial"),  # or the last migration name for events
    ]

    operations = [
        migrations.AddField(
            model_name="event",
            name="dyte_meeting_id",
            field=models.CharField(max_length=255, blank=True, null=True),
        ),
        migrations.AddField(
            model_name="event",
            name="dyte_meeting_title",
            field=models.CharField(max_length=255, blank=True, null=True),
        ),
    ]
